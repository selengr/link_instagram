import styles from "../../styles/components/banner/banner.module.css"


const Bio = () => {
    return (
        <section className={styles["landing-page-content-inner"]}>
            
            <div>

              <span >testing</span>
            </div>

            <div>
                
              <span className={styles["landing-hover-highlight"]}>Lorem amet consectetur adipisicing elit. Deleniti voluptate aut eveniet, </span>
            </div>

      
           
        </section>
    );
}

export default Bio;