"use client";


import {useState} from "react";
import "../../../styles/globals.css";
export const metadata = {
    title: 'Next.js',
    description: 'reza ',
}
import Header from "@/components/header";

export default function RootLayout({
                                       children,
                                   }: {
    children: React.ReactNode
}) {
    const [darkMode, setDarkMode] = useState(false);



    return (
        <html lang="en" data-theme="light">


        <body className="bg-primary text-primary " >


        <div className={"bg-primary h[100px]"} />
              {children}
        </body>
        </html>
    )
}
