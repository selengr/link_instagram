'use client'
import "../../../styles/globals.css";

const CreatePost = () => {


    return (
        <>
dff
        </>
    );
};

export default CreatePost;
