import styles from "../../styles/components/header/header.module.css"

const Header = () => {
    return (
        <>
            <div className={styles["landing-top"]}>
               ddd
            </div>

           
        </>
    );
}

export default Header;